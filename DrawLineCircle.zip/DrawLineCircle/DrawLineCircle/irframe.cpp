#include "irframe.h"
#include <QPainter>
#include <QGraphicsBlurEffect>
#include <QTimer>
#include <QDebug>

#define LABEL_WIDTH 160
#define LABEL_HEIGHT 40
#define SPACE_IR  20


IrFrame::IrFrame(QWidget *parent) :
    QFrame(parent)
    ,mp_transparent_ir_label( NULL )
    ,mp_pt_start( NULL )
    ,mp_pt_middle( NULL )
    ,mp_pt_end( NULL )
    ,mp_ir_slider( NULL )
    ,mn_ir_slider_value( 0 )
{
    init_ir_widget();
    //press_status = false;
    //draw_status = false;
    //mp_ir_slider = new QSlider( Qt::Vertical );

}

IrFrame::~IrFrame()
{

}

void IrFrame::init_ir_widget() {
    mp_transparent_ir_label = new QLabel( this );
    QGraphicsOpacityEffect *effect = new QGraphicsOpacityEffect( this );
    effect->setOpacity( 0.8 );
    mp_transparent_ir_label->setGraphicsEffect( effect );
    mp_transparent_ir_label->hide();

    m_list.append( "点" );
    m_list.append( "线" );
    m_list.append( "框" );
    m_list.append( "圆" );
    qDebug()<<"RealTime:ir_list"<<m_list;
}

void IrFrame::set_ir_slider( IrSlider *p_ir_slider )
{
    mp_ir_slider = p_ir_slider;
    //设置QSlider的范围
    mp_ir_slider->setRange( 0, 100 );
    //在拖动条上按一下改变的值
    //mp_slider_play->setPageStep( 10 );
    //设置显示刻度的位置
    mp_ir_slider->setTickPosition( QSlider::TicksRight );
    connect( mp_ir_slider, SIGNAL( signal_value_change(int) ), this, SLOT( slot_value_change(int) ) );
    QTimer *timer = new QTimer( this );
    //开始运行定时器，定时时间间隔为1000ms
    connect( timer, SIGNAL( timeout() ), this, SLOT( slot_slider_value() ) );
    timer->start( 50 );
    //将定时器超时信号与槽(功能函数)联系起来

}

void IrFrame::slot_slider_value()
{
    static int n = 0;
    if( mp_ir_slider->get_value_status() ) {//按下
        //n = mp_ir_slider->get_value_pos();
        n = mn_ir_slider_value;
    } else {
        n = ++n>100?0:n;
        mp_ir_slider->setValue( n );
    }
}

void IrFrame::slot_value_change( int n_pos )
{
    mn_ir_slider_value = n_pos;
}

void IrFrame::paintEvent( QPaintEvent *event )
{
    QPainter draw;
    draw.begin( this );
    draw.fillRect( 0, 0, width(), height(), QBrush( QColor( 125,125,125 ) ) );

    int n_size = m_list.size();
    QList<QString>::iterator i;
    int j = 0;
    int n_width = LABEL_WIDTH/4;
    int n_height = LABEL_HEIGHT;
    for( i=m_list.begin(),j=0; i!=m_list.end(); i++,j++ ) {
        draw.setPen( Qt::white );
        draw.drawText( mp_transparent_ir_label->x()+n_width*j, mp_transparent_ir_label->y(), n_width, n_height, Qt::AlignCenter, *i );
        draw.setPen( Qt::black );
        draw.drawRect( mp_transparent_ir_label->x()+n_width*j, mp_transparent_ir_label->y(), n_width, n_height );
    }

    draw.end();
}

void IrFrame::resizeEvent( QResizeEvent *event )
{
    mp_transparent_ir_label->move( SPACE_IR, SPACE_IR );
    mp_transparent_ir_label->resize( LABEL_WIDTH, LABEL_HEIGHT );
}

void IrFrame::mousePressEvent( QMouseEvent *event )
{
    if ( event->button() == Qt::LeftButton ) {
        /*if( point_status ) {
            //点，最终应该考虑释放位置的点

            draw_point_status = true;
        } else if( line_status ) {
            draw_line_status = true;
        } else if( rect_status ) {
            draw_rect_status = true;
        } else if( circle_status ){
            draw_circle_status = true;
        }

        //如果鼠标点击 点 线位置   ，mb_ana_status =true
        int n_width = LABEL_WIDTH/4;
        int i = 0;
        for( ; i<4; i++ ) {
            if( event->x()>SPACE_IR+n_width*i && event->x()<= SPACE_IR+n_width*(i+1) && event->y()>SPACE_IR && event->y()<=SPACE_IR+LABEL_HEIGHT ) {
                switch ( i ) {
                case 1:
                    point_status = true;
                    break;
                case 2:
                    line_status = true;
                    break;
                case 3:
                    rect_status = true;
                    break;
                case 4:
                    circle_status = true;
                    break;
                }
            }
        }*/
    }
}

void IrFrame::mouseMoveEvent( QMouseEvent *event )
{


}

void IrFrame::mouseReleaseEvent( QMouseEvent *event )
{
    if ( event->button() == Qt::LeftButton ) {

    }
}
