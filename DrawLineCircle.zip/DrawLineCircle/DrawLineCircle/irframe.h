#ifndef IRFRAME_H
#define IRFRAME_H

#include <QFrame>
#include <QLabel>
#include <QList>
#include <QMouseEvent>
#include <QSlider>
#include "irslider.h"

class IrFrame : public QFrame
{
    Q_OBJECT
public:
    explicit IrFrame(QWidget *parent = 0);
    ~IrFrame();
public:
    enum {
        point_status,
        line_status,
        rect_status,
        circle_status
    } press_status;
    enum {
        draw_point_status,
        draw_line_status,
        draw_rect_status,
        draw_circle_status
    } draw_status;

    void paintEvent( QPaintEvent *event );
    void resizeEvent( QResizeEvent *event );
    void mousePressEvent( QMouseEvent *event );
    void mouseMoveEvent( QMouseEvent *event );
    void mouseReleaseEvent( QMouseEvent *event );
    void init_ir_widget();
    void set_ir_slider( IrSlider *p_ir_slider );
signals:

public slots:
    void slot_slider_value();
    void slot_value_change( int n_pos );
private:
    QLabel *mp_transparent_ir_label;
    QList<QString> m_list;
    QPoint *mp_pt_start;
    QPoint *mp_pt_middle;
    QPoint *mp_pt_end;
    IrSlider *mp_ir_slider;
    int mn_ir_slider_value;
    bool mb_press_status;
    bool mb_draw_status;
};

#endif // IRFRAME_H
