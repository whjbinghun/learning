﻿#ifndef FILE_STORAGEANADATA_H
#define FILE_STORAGEANADATA_H

#include <QVector>

#include "datacommon.h"

typedef struct
{
    unsigned int n_ana_id;      // 分析号
    YF_ANA_CHART_TREND_POINT pts; // 点结构体
}StorageAnaPackage;


class FileStorageAnaData
{
public:
    /**
     * @brief save
     * @param n_preset_id
     * @param map_pts
     */
    void save( const QString str_file_name, const QMap<int, QList< YF_ANA_CHART_TREND_POINT > > & map_pts );
    /**
     * @brief load
     * @param n_preset_id
     * @param map_pts
     */
    void load( const QString str_file_name, QMap<int, QList< YF_ANA_CHART_TREND_POINT > > & map_pts );
};



#endif // FILE_STORAGEANADATA_H
